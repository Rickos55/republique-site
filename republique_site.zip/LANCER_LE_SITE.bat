@echo off
chcp 65001 >nul
title Republique - Politique Francaise
cd /d "%~dp0"

echo.
echo  =====================================================
echo   REPUBLIQUE - Demarrage
echo  =====================================================
echo.
pause

:: Recharger le PATH
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "PATH=%%B;%PATH%"

:: Tester Node
echo  [*] Test Node.js...
node --version
if %errorlevel% neq 0 (
    echo  [ERREUR] Node.js introuvable !
    echo  Installez-le sur https://nodejs.org puis REDEMARREZ votre PC
    pause
    exit /b 1
)
echo  [OK] Node trouve !
pause

:: package.json
if not exist package.json (
    echo {"name":"republique","version":"1.0.0","main":"server.js"} > package.json
)

:: npm install
if not exist node_modules\express (
    echo  [*] Installation modules npm...
    call npm install express node-fetch@2 abort-controller --save
    echo  Resultat npm : %errorlevel%
    pause
)

:: Cle API
if not exist api_key.txt (
    echo.
    echo  Entrez votre cle API Anthropic (ou appuyez Entree pour ignorer)
    set /p APIKEY="  Cle : "
    setlocal enabledelayedexpansion
    if not "!APIKEY!"=="" (
        echo !APIKEY!> api_key.txt
    )
    endlocal
)

:: Lancer
echo.
echo  [*] Lancement du serveur...
echo  Ouvrez http://localhost:3000 dans votre navigateur
echo  Ne fermez PAS cette fenetre !
echo.
start "" cmd /c "timeout /t 3 >nul & start http://localhost:3000"
node server.js

pause
